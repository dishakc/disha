package com.niit.shopingcart;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.ProductDAO;

public class ProductTest 
{

	private static AnnotationConfigApplicationContext context;
	
	private static ProductDAO productDAO;
	
	@BeforeClass
	public static void init()

	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		productDAO =(ProductDAO)context.getBean("productDAO");	
	}
	

	@Test
	public void ListTest() 
	{
		assertEquals("ListProduct",11,productDAO.list().size());
	}
	
	@Test
	public void getTest() 
	{
		
	}
	
	@Test
	public void saveOrUpdateTest() 
	{
		
	}
	
	@Test
	public void deleteTest() 
	{
		
	}
	
	

}

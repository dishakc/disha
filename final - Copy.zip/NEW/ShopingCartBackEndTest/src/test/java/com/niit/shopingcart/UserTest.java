package com.niit.shopingcart;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shopingcart.dao.UserDAO;

public class UserTest 
{

AnnotationConfigApplicationContext context;
	
	UserDAO userDAO;
	
	@BeforeClass
	public void init()

	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		userDAO=(UserDAO)context.getBean("userDAO");	
	}
	

	@Test
	public void ListTest() 
	{
		assertEquals("ListCategory",5,userDAO.list().size());
	}
	
	@Test
	public void UsergetTest() 
	{
		
	}
	
	@Test
	public void saveOrUpdateTest() 
	{
		
	}
	
	@Test
	public void deleteTest() 
	{
		
	}
	
	@Test
	public void isValidUserTest() 
	{
		assertEquals("Valid user Test case ",true ,userDAO.isValidUser("admin", "admin",true));
	}
	
	

}
